﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//benodigde tijd 15minuten (na nog eens uitleg te krijgen in labo)
namespace Labo6_3e
{
    public enum Menus { General, Add = 1, ShowNames, Edit, Search, Exit }
    class Program
    {
        public static Person test = new Person("", "", "", "", "", "", "");
        public static List<Person> Persons = new List<Person>();
        static void Main(string[] args)
        {
            Menu Main = new Menu(Menus.General);
            ICommand add = new AddPersonCommand(Menus.Add);
            Main.AddCommand(add);
            ICommand display = new DisplayPersonsCommand(Menus.ShowNames);
            Main.AddCommand(display);
            ICommand edit = new EditPersonCommand(Menus.Edit);
            Main.AddCommand(edit);
            ICommand search = new Search(Menus.Search);
            Main.AddCommand(search);
            ICommand exit = new Search(Menus.Exit);
            Main.AddCommand(exit);
            int ToDo = 0;
            while (ToDo != 5)
            {
                Main.Run();
                ToDo = Convert.ToInt32(Console.ReadLine());
                switch (ToDo)
                {
                    case 1:
                        add.Run();
                        break;
                    case 2:
                        display.Run();
                        break;
                    case 3:
                        edit.Run();
                        break;
                    case 4:
                        Console.WriteLine("1:Naam?");
                        Console.WriteLine("2:Leeftijd?");
                        int x = Convert.ToInt32(Console.ReadLine());
                        switch(x)
                        {
                            case 1:
                                {
                                    Console.WriteLine("Naam?");
                                    test.edit(Console.ReadLine(), "", "", "", "", "", "");
                                    List<Person> FilteredNumbers = Filter(Persons, new Naam());
                                    foreach (Person item in FilteredNumbers)
                                    {
                                        Console.WriteLine(item);
                                    }
                                    break;
                                }
                            case 2:
                                {
                                    Console.WriteLine("Leeftijd?");
                                    test.edit("", "", Console.ReadLine(), "", "", "", "");
                                    List<Person> FilteredNumbers = Filter(Persons, new Age());
                                    foreach (Person item in FilteredNumbers)
                                    {
                                        Console.WriteLine(item);
                                    }
                                    break;
                                }
                        }
                        break;
                    default:
                        Console.WriteLine("Wrong input");
                        break;
                }
            }
        }
   
        static List<T> Filter<T>(IEnumerable<T> arr, Ifilter<T> filter)
        {
            List<T> result = new List<T>();
            foreach (T y in arr)
            {
                if (filter.Filter(y))
                {
                    result.Add(y);
                }
            }
            return result;
        }
    }
}