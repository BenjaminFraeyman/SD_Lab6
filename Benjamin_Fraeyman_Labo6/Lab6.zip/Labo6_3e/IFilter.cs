﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo6_3e
{
    public interface Ifilter<T>
    {
        bool Filter(T element);
    }

    public class Naam : Ifilter<Person>
    {
        public bool Filter(Person element1)
        {
            return (element1.Naam == Program.test.Naam);
        }
    }

    public class Age : Ifilter<Person>
    {
        public bool Filter(Person element1)
        {
            return (element1.Leeftijd == Program.test.Leeftijd);
        }
    }
}
