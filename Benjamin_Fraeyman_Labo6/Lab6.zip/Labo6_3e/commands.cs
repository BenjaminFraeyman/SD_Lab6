﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo6_3e
{
    abstract class ICommand
    {
        public Menus X { get; private set; }
        public ICommand(Menus x) // constructor
        {
            X = x;
        }
        public abstract void Run(); // methode die dient te worden ingevoegd in klassen die hiervan overerven
    }

    class Menu : ICommand
    {
        public List<ICommand> Commandos { get; private set; }
        public Menu(Menus x) : base(x)
        {
            Commandos = new List<ICommand>();
        }
        public void AddCommand(ICommand command)
        { Commandos.Add(command); }
        public override void Run()
        {
            Console.WriteLine("~+~+~+~+~+~+");
            foreach (ICommand command in Commandos)
            {
                Console.WriteLine((int)command.X + ": " + command.X);
            }
            Console.WriteLine("~+~+~+~+~+~+");
        }
    }

    class AddPersonCommand : ICommand
    {
        public AddPersonCommand(Menus x) : base(x)
        { }
        public override void Run()
        {
            Console.WriteLine("voornaam?");
            string Naam = (Console.ReadLine());
            Console.WriteLine("familienaam?");
            string VoorNaam = (Console.ReadLine());
            Console.WriteLine("leeftijd?");
            string Leeftijd = (Console.ReadLine());
            Console.WriteLine("stad?");
            string Stad = (Console.ReadLine());
            Console.WriteLine("postcode?");
            string Postcode = (Console.ReadLine());
            Console.WriteLine("straat?");
            string Straat = (Console.ReadLine());
            Console.WriteLine("nummer?");
            string Nummer = (Console.ReadLine());
            Program.Persons.Add(new Person(Naam, VoorNaam, Leeftijd, Stad, Postcode, Straat, Nummer));
        }
    }

    class DisplayPersonsCommand : ICommand
    {
        public DisplayPersonsCommand(Menus x) : base(x)
        { }
        public override void Run()
        {
            foreach (Person tekst in Program.Persons)
            {
                Console.WriteLine(tekst);
            }
        }
    }

    class EditPersonCommand : ICommand
    {
        public EditPersonCommand(Menus x) : base(x)
        { }
        public override void Run()
        {

            int nummer = 1;
            foreach (Person tekst in Program.Persons)
            {
                Console.WriteLine(nummer + ": " + tekst.VoorNaam);
                nummer++;
            }


            int toedit = Convert.ToInt32(Console.ReadLine());
            toedit -= 1;
            Person temp = Program.Persons[toedit];

            Console.WriteLine("voornaam?");
            string Naam = (Console.ReadLine());
            Console.WriteLine("familienaam?");
            string VoorNaam = (Console.ReadLine());
            Console.WriteLine("leeftijd?");
            string Leeftijd = (Console.ReadLine());
            Console.WriteLine("stad?");
            string Stad = (Console.ReadLine());
            Console.WriteLine("postcode?");
            string Postcode = (Console.ReadLine());
            Console.WriteLine("straat?");
            string Straat = (Console.ReadLine());
            Console.WriteLine("nummer?");
            string Nummer = (Console.ReadLine());
            temp.edit(Naam, VoorNaam, Leeftijd, Stad, Postcode, Straat, Nummer);
        }
    }

    class Search : ICommand
    {
        public Search(Menus x) : base(x)
        { }
        public override void Run()
        {
        }
    }
}