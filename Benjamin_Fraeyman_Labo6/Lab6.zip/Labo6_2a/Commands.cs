﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo6_2a
{
    abstract class ICommand
    {
        public Menus X { get; private set; }
        public ICommand(Menus x) // constructor
        {
            X = x;
        }
        public abstract void Run(); // methode die dient te worden ingevoegd in klassen die hiervan overerven
    }

    class Menu : ICommand
    {
        public List<ICommand> Commandos { get; private set; }
        public Menu(Menus x) : base(x)
        {
            Commandos = new List<ICommand>();
        }
        public void AddCommand(ICommand command)
        { Commandos.Add(command); }
        public override void Run()
        {
            Console.WriteLine("~+~+~+~+~+~+");
            foreach (ICommand command in Commandos)
            {
                Console.WriteLine((int)command.X + ": " + command.X);
            }
            Console.WriteLine("~+~+~+~+~+~+");
        }
    }

    class AddPersonCommand : ICommand
    {
        public AddPersonCommand(Menus x) : base(x)
        { }
        public override void Run()
        {
            Console.WriteLine("voornaam?");
            Program.Persons.Add(Console.ReadLine());
            Console.WriteLine("familienaam?");
            Program.Persons.Add(Console.ReadLine());
            Console.WriteLine("leeftijd?");
            Program.Persons.Add(Console.ReadLine());
            Console.WriteLine("stad?");
            Program.Persons.Add(Console.ReadLine());
            Console.WriteLine("postcode?");
            Program.Persons.Add(Console.ReadLine());
            Console.WriteLine("straat?");
            Program.Persons.Add(Console.ReadLine());
            Console.WriteLine("nummer?");
            Program.Persons.Add(Console.ReadLine());
        }
    }

    class DisplayPersonsCommand : ICommand
    {
        public DisplayPersonsCommand(Menus x) : base(x)
        { }
        public override void Run()
        {
            foreach (string tekst in Program.Persons)
            {
                Console.WriteLine(tekst);
            }
        }
    }

    class EditPersonCommand : ICommand
    {
        public EditPersonCommand(Menus x) : base(x)
        { }
        public override void Run()
        {
            int n = 0;
            int nummer = 1;

            while (n < Program.Persons.Count)
            {
                Console.WriteLine(nummer + ": " + Program.Persons[n]);
                n += 7;
                nummer++;
            }
            int toedit = Convert.ToInt32(Console.ReadLine());
            toedit = (toedit - 1) * 7;
            Console.WriteLine("voornaam?");
            Program.Persons[toedit] = Console.ReadLine();
            Console.WriteLine("familienaam?");
            Program.Persons[toedit + 1] = Console.ReadLine();
            Console.WriteLine("leeftijd?");
            Program.Persons[toedit + 2] = Console.ReadLine();
            Console.WriteLine("stad?");
            Program.Persons[toedit + 3] = Console.ReadLine();
            Console.WriteLine("postcode?");
            Program.Persons[toedit + 4] = Console.ReadLine();
            Console.WriteLine("straat?");
            Program.Persons[toedit + 5] = Console.ReadLine();
            Console.WriteLine("nummer?");
            Program.Persons[toedit + 6] = Console.ReadLine();
        }
    }
}