﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo6_2c
{
    class Person
    {
        public string Naam { get; private set; }
        public string VoorNaam { get; private set; }
        public string Leeftijd { get; private set; }
        public string Stad { get; private set; }
        public string Postcode { get; private set; }
        public string Straat { get; private set; }
        public string Nummer { get; private set; }

        public Person(string naam, string voornaam, string leeftijd, string stad, string postcode, string straat, string nummer)
        {
            Naam = naam;
            VoorNaam = voornaam;
            Leeftijd = leeftijd;
            Stad = stad;
            Postcode = postcode;
            Straat = straat;
            Nummer = nummer;
        }
        public override string ToString()
        {
            return Naam + " " + VoorNaam + " " + Leeftijd + " " + Stad + " " + Postcode + " " + Straat + " " + Nummer;
        }

        public void edit(string naam, string voornaam, string leeftijd, string stad, string postcode, string straat, string nummer)
        {
            Naam = naam;
            VoorNaam = voornaam;
            Leeftijd = leeftijd;
            Stad = stad;
            Postcode = postcode;
            Straat = straat;
            Nummer = nummer;
        }

    }
}
