﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//benodigde tijd 15minuten
namespace Labo6_2c //Labo6_2b
{
    public enum Menus { General, Add = 1, ShowNames, Edit }
    class Program
    {
        public static ArrayList Persons = new ArrayList();
        static void Main(string[] args)
        {
            Menu Main = new Menu(Menus.General);
            ICommand add = new AddPersonCommand(Menus.Add);
            Main.AddCommand(add);
            ICommand display = new DisplayPersonsCommand(Menus.ShowNames);
            Main.AddCommand(display);
            ICommand edit = new EditPersonCommand(Menus.Edit);
            Main.AddCommand(edit);
            while (true)
            {
                Main.Run();
                int ToDo = Convert.ToInt32(Console.ReadLine());
                switch (ToDo)
                {
                    case 1:
                        add.Run();
                        break;
                    case 2:
                        display.Run();
                        break;
                    case 3:
                        // niet vergeten te casten naar een lijst
                        edit.Run();
                        break;
                    default:
                        Console.WriteLine("Default case");
                        break;
                }
                Console.ReadLine();
            }
        }
    }
}