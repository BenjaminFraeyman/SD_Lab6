﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//benodigde tijd 10minuten (na nog eens uitleg te krijgen in labo)
namespace Labo6_3d
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> Numbers = new List<int>();
            Console.WriteLine("geef maximum waarde op");
            int max = Convert.ToInt32(Console.ReadLine()); // max waarde
            for (int i = 2; i < max; i++) // aanmaak array met alle elementen van 0 tot max
            {
                Numbers.Add(i);
            }
            List<int> FilteredNumbers = Filter(Numbers, new Priem());
            foreach (int x in FilteredNumbers)
            {
                Console.WriteLine(x);
            }
            Console.ReadLine();
        }

        static List<T> Filter<T>(IEnumerable<T> arr, Ifilter<T> filter)
        {
            List<T> result = new List<T>();
            foreach (T x in arr)
            {
                if (filter.Filter(x))
                {
                    result.Add(x);
                }
            }
            return result;
        }

        public interface Ifilter<T>
        {
            bool Filter(T element);
        }

        public class Priem : Ifilter<int>
        {
            public bool Filter(int element1)
            {
                List<int> Numbers = new List<int>();
                for (int i = 2; i < element1; i++) // aanmaak array met alle elementen van 0 tot max
                {
                    Numbers.Add(i);
                }
                int test = 0;
                int temp = Numbers.Count;
                foreach (int y in Numbers)
                {
                    if (element1 != y && element1 % y != 0 && element1 > y)
                    {
                        test++;
                    }
                }
                return (test == temp);
            }
        }
    }
}