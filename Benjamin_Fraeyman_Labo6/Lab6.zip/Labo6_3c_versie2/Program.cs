﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//benodigde tijd 10minuten (na nog eens uitleg te krijgen in labo)
namespace Labo6_3c_versie2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5;
            int b = 2;
            List<int> arr = new List<int>();
            arr.Add(a);
            arr.Add(b);
            List<int> filtered = Filter(arr, new Even());
        }

        static List<T> Filter<T>(IEnumerable<T> arr, Ifilter<T> filter)
        {
            List<T> result = new List<T>();
            foreach (T x in arr)
            {
                if (filter.Filter(x))
                {
                    result.Add(x);
                }
            }
            return result;
        }

        public interface Ifilter<T>
        {
            bool Filter(T element);
        }

        public class Even : Ifilter<int>
        {
            public bool Filter(int element1)
            {
                return (element1 % 2 == 0);
            }
        }

        public class OnEven : Ifilter<int>
        {
            public bool Filter(int element1)
            {
                return (element1 % 2 != 0);
            }
        }
    }

}

