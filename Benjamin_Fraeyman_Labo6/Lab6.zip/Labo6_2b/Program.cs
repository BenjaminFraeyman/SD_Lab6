﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//benodigde tijd 10minuten
namespace Labo6_2b   // Labo6_2C
{
    public enum Menus { General, Add = 1, ShowNames, Edit }
    class Program
    {
        public static List<Person> Persons = new List<Person>();
        static void Main(string[] args)
        {
            Menu Main = new Menu(Menus.General);
            ICommand add = new AddPersonCommand(Menus.Add);
            Main.AddCommand(add);
            ICommand display = new DisplayPersonsCommand(Menus.ShowNames);
            Main.AddCommand(display);
            ICommand edit = new EditPersonCommand(Menus.Edit);
            Main.AddCommand(edit);
            while (true)
            {
                Main.Run();
                int ToDo = Convert.ToInt32(Console.ReadLine());
                switch (ToDo)
                {
                    case 1:
                        add.Run();
                        break;
                    case 2:
                        display.Run();
                        break;
                    case 3:
                        //aanpassen is zeer gemakkelijk
                        edit.Run();
                        break;
                    default:
                        Console.WriteLine("Default case");
                        break;
                }
                Console.ReadLine();
            }
        }
    }
}