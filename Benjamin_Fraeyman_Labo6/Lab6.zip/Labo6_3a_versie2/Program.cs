﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//benodigde tijd 1minuten (na nog eens uitleg te krijgen in labo)
namespace Labo6_3a_versie2
{
    class Program
    {
        static void Main(string[] args)
        {}
    }

    public interface Ifilter
    {
        bool Filter();
    }
}

