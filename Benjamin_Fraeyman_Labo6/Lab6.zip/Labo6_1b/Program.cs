﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Security;
using System.IO;
using System.Runtime.InteropServices;

namespace Labo6_1b
{
    public class Program
    {
        public static void Main()
        {
            string path = @"C:\Users\Benjamin\Desktop\softwareontw\Labo6_1\Labo6_1\bin\Debug\test5.txt";
            using (AesManaged algo = new AesManaged())
            {
                string passwd = "Slecht Wachtwoord";
                byte[] bytePwd = Encoding.ASCII.GetBytes(passwd);
                SHA256 hash = SHA256Managed.Create();
                byte[] key = hash.ComputeHash(bytePwd);
                byte[] iv = hash.ComputeHash(key);
                algo.KeySize = 128;
                byte[] Key = new byte[algo.Key.Length];
                byte[] IV = new byte[algo.IV.Length];
                for (int iv0 = 0; iv0 < algo.Key.Length; ++iv0)
                    Key[iv0] = key[iv0];
                for (int iv0 = 0; iv0 < algo.IV.Length; ++iv0)
                    IV[iv0] = iv[iv0];
                algo.Key = Key;
                algo.IV = IV;
            
                List<Card> kaarten = new List<Card>();
                ICryptoTransform decryptor = algo.CreateDecryptor();
                using (FileStream fsIn = new FileStream(path, FileMode.Open))
                using (MemoryStream msOut = new MemoryStream(100))
                using (CryptoStream sDecrypt = new CryptoStream(fsIn, decryptor, CryptoStreamMode.Read))
                using (BinaryReader fsBR = new BinaryReader(msOut))
                {
                    sDecrypt.CopyTo(msOut);
                    long pos = msOut.Seek(0, SeekOrigin.Begin);
                    while (msOut.Position < msOut.Length)
                    {
                        kaarten.Add(new Card(fsBR));                   
                    }
                    foreach (Card kaart in kaarten)
                        Console.WriteLine(kaart);
                }
                Console.ReadLine();           
            }
        }
    }

    class Card // welke eigenschappen de kaarten bevatten
    {
        public string Image { get; private set; }
        public int Value { get; private set; }
        public bool Turned { get; private set; }
        // aanmaak van een kaartje
        public Card(BinaryReader fsBR)
        {
            Image = fsBR.ReadString();
            Value = fsBR.ReadInt32();
            Turned = fsBR.ReadBoolean();
        }
        public override string ToString() // uitprinten
        {
            return "[" + Image + "-" + Value + "]";
        }
        public void Write(BinaryWriter fsBW)
        {
            fsBW.Write(Image);
            fsBW.Write(Value);
            fsBW.Write(Turned);
        }
    }   
}