﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo6_1
{
    class Card // welke eigenschappen de kaarten bevatten
    {
        public string Image { get; private set; }
        public int Value { get; private set; }
        public bool Turned { get; private set; }
        // aanmaak van een kaartje
        public Card(string im, int val, bool turn)
        {
            Image = im;
            Value = val;
            Turned = turn;
        }
        public override string ToString() // uitprinten
        {
            return "[" + Image + "-" + Value + "]";
        }

        public void Write(BinaryWriter fsBW)
        {
            fsBW.Write(Image);
            fsBW.Write(Value);
            fsBW.Write(Turned);
        }
    }

    class Cards
    {
        Random random = new Random();
        public List<string> Images = new List<string>(); // plaatjes
        public List<Card> OriginalDeck = new List<Card>(); // niet willekeurig deck
        public void Generate(int amount) // kaarten genereren
        {
            // aanmaken van je spel kaarten
            for (int value = 0; value < amount; value++)
            {
                for (int i = 0; i < Images.Count; i++)
                {
                    string image = Images[i];
                    Card card = new Card(image, value, false);
                    OriginalDeck.Add(card);
                }
            }
        } 
    }
}