﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Security;
using System.IO;
using System.Runtime.InteropServices;

//benodigde tijd 20minuten (lezen+schrijven)
namespace Labo6_1
{
    public class Program
    {
        public static void Main()
        {
            Cards deck = new Cards();
            Boolean Add = true;
            while (Add)
            {
                string YesNo;
                Console.WriteLine("Een plaatje toevoegen?(ja/nee)");
                YesNo = Console.ReadLine();
                if (YesNo == "ja")
                {
                    Console.WriteLine("Welk plaatje?");
                    deck.Images.Add(Console.ReadLine());
                }
                else if (YesNo == "nee")
                {
                    if (deck.Images.Count > 1)
                    { Add = false; }
                    else { Console.WriteLine("Geef minimum 2 plaatjes op."); }
                }
            }
            Console.WriteLine("Hoeveel kaarten bestaan er per plaatje?");
            int amount = Convert.ToInt32(Console.ReadLine());
            deck.Generate(amount);

            string path = @"C:\Users\Benjamin\Desktop\softwareontw\Labo6_1\Labo6_1\bin\Debug\test5.txt";
            if (File.Exists(path)) File.Delete(path);
            using (AesManaged algo = new AesManaged())
            {
                string passwd = "Slecht Wachtwoord";
                byte[] bytePwd = Encoding.ASCII.GetBytes(passwd);
                SHA256 hash = SHA256Managed.Create();
                byte[] key = hash.ComputeHash(bytePwd);
                byte[] iv = hash.ComputeHash(key);
                algo.KeySize = 128;
                byte[] Key = new byte[algo.Key.Length];
                byte[] IV = new byte[algo.IV.Length];
                for (int iv0 = 0; iv0 < algo.Key.Length; ++iv0)
                    Key[iv0] = key[iv0];
                for (int iv0 = 0; iv0 < algo.IV.Length; ++iv0)
                    IV[iv0] = iv[iv0];
                algo.Key = Key;
                algo.IV = IV;


                ICryptoTransform encryptor = algo.CreateEncryptor();
                using (MemoryStream msIn = new MemoryStream(100))
                using (BinaryWriter fsBW = new BinaryWriter(msIn))
                using (FileStream fsOut = new FileStream(path, FileMode.CreateNew))
                using (CryptoStream sCrypt = new CryptoStream(fsOut, encryptor, CryptoStreamMode.Write))
                {
                    foreach (Card kaart in deck.OriginalDeck) { kaart.Write(fsBW); }
                    long pos = msIn.Seek(0, SeekOrigin.Begin);
                    msIn.CopyTo(sCrypt); sCrypt.Flush();
                }
                Console.ReadLine();
            }
        }
    }
}
