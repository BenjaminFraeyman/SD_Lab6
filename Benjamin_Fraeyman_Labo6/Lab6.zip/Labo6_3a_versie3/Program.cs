﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo6_3a_versie3
{
    public enum Filters { Persoon, Naam = 1, VoorNaam, Leeftijd, Stad, Postcode, Straat, Nummer }
    class Program
    {
        public static List<Person> Persons = new List<Person>();
        public static List<Person> FilteredPersons = new List<Person>();
        static void Main(string[] args)
        {
        }
    }

    abstract class IFilter
    {
        public Filters X { get; private set; }
        public IFilter(Filters x) // constructor
        {
            X = x;
        }
        public abstract void Filter(); // methode die dient te worden ingevoegd in klassen die hiervan overerven
    }

    class Filtername : IFilter
    {
        public Filtername(Filters x) : base(x)
        { }
        public override void Filter()
        {
            Console.WriteLine("familienaam?");
            string Naam = (Console.ReadLine());
            foreach (Person item in Program.Persons)
            {
                if (item.Naam.Equals(Naam))
                {
                    Program.FilteredPersons.Add(item);
                }
            }
        }
    }

    class Person
    {
        public string Naam { get; private set; }
        public string VoorNaam { get; private set; }
        public string Leeftijd { get; private set; }
        public string Stad { get; private set; }
        public string Postcode { get; private set; }
        public string Straat { get; private set; }
        public string Nummer { get; private set; }

        public Person(string naam, string voornaam, string leeftijd, string stad, string postcode, string straat, string nummer)
        {
            Naam = naam;
            VoorNaam = voornaam;
            Leeftijd = leeftijd;
            Stad = stad;
            Postcode = postcode;
            Straat = straat;
            Nummer = nummer;
        }
        public override string ToString()
        {
            return Naam + " " + VoorNaam + " " + Leeftijd + " " + Stad + " " + Postcode + " " + Straat + " " + Nummer;
        }

        public void edit(string naam, string voornaam, string leeftijd, string stad, string postcode, string straat, string nummer)
        {
            Naam = naam;
            VoorNaam = voornaam;
            Leeftijd = leeftijd;
            Stad = stad;
            Postcode = postcode;
            Straat = straat;
            Nummer = nummer;
        }

    }
}
}
